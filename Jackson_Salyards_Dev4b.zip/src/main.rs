use cs_317_movie_project::gui_draw;
#[tokio::main]
async fn main() {
    gui_draw::init().await;
}
